RegisterNetEvent("cls-whitelist:client:openWhitelistMenu", function()
    local dialog = exports['qb-input']:ShowInput({
        header = "Whitelist Ekle",
        submitText = "Ekle",
        inputs = {
            {
                text = "Steam HEX ID (steam:11000010xxxxx)", -- Kullanıcıdan giriş al
                name = "hexID",
                type = "text",
                isRequired = true
            }
        }
    })

    if dialog and dialog.hexID then
        TriggerServerEvent("cls-whitelist:server:addToWhitelist", dialog.hexID)
    else
        TriggerEvent("QBCore:Notify", "İşlem iptal edildi!", "error")
    end
end)