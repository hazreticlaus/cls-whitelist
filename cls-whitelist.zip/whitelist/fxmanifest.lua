fx_version 'cerulean'
game 'gta5'

author 'clsdev'
description 'qb altyapılı basic whitelist scripti'
version '1.0.0'

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server.lua'
}

client_script 'client.lua'