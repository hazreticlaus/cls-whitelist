local QBCore = exports['qb-core']:GetCoreObject()

AddEventHandler('playerConnecting', function(name, setCallback, deferrals)
    local src = source
    deferrals.defer()
    Wait(100)

    local identifiers = GetPlayerIdentifiers(src)
    local steamHex = nil

    -- Steam HEX ID'yi al
    for _, v in ipairs(identifiers) do
        if string.find(v, "steam:") then
            steamHex = v
            break
        end
    end

    if not steamHex then
        deferrals.done("❌ Steam açılmadan giriş yapamazsınız!")
        return
    end


    MySQL.Async.fetchScalar('SELECT COUNT(*) FROM whitelist WHERE steam_hex = ?', {steamHex}, function(count)
        if count > 0 then
            deferrals.done() 
        else
            deferrals.done("❌ Bu sunucuya giriş için whitelist'e eklenmelisiniz!\n\n🔹 yetkili ile iletişime geçin.")
        end
    end)
end)


QBCore.Commands.Add("whitelist", "Oyuncuyu Whitelist'e ekle", {}, false, function(source)
    local src = source

    TriggerClientEvent("cls-whitelist:client:openWhitelistMenu", src)
end, "god")

RegisterNetEvent("cls-whitelist:server:addToWhitelist", function(hexID)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)

    RegisterServerEvent('cls-whitelist:adminchecker')
    AddEventHandler('cls-whitelist:adminchecker', function()
    local src = source
    if IsPlayerAceAllowed(src, "command") then
        TriggerClientEvent('cls-whitelist:komutlar', src)
    else
        TriggerClientEvent('QBCore:Notify', src, "Bu komutu sadece adminler kullanabilir", "error")
      end
    end)

    if not string.match(hexID, "^steam:1100001[0-9A-Fa-f]+$") then
        TriggerClientEvent("QBCore:Notify", src, "❌ Geçersiz Steam HEX ID!", "error")
        return
    end


    MySQL.Async.fetchScalar('SELECT COUNT(*) FROM whitelist WHERE steam_hex = ?', {hexID}, function(count)
        if count > 0 then
            TriggerClientEvent("QBCore:Notify", src, "⚠️ Bu oyuncu zaten whitelist'te!", "warning")
        else

            MySQL.Async.execute('INSERT INTO whitelist (steam_hex) VALUES (?)', { hexID }, function(rowsChanged)
                if rowsChanged > 0 then
                    TriggerClientEvent("QBCore:Notify", src, "✅ Oyuncu whitelist'e eklendi!", "success")
                else
                    TriggerClientEvent("QBCore:Notify", src, "❌ Whitelist eklenirken hata oluştu!", "error")
                end
            end)
        end
    end)
end)